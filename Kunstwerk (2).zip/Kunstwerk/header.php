<?php
include './includes/dbh.php';
?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>
<?php

if ($_SESSION && $_SESSION['user']) {
    echo '<header>
        <div class="logo-container">
        </div>
        <ul>
          <button onclick="logout()" class="logout-button">Logout</button>
        </ul>
    </header>';
} else {
    echo '<header class="login-header">
        <div class="logo-container">
        </div>
        <div class="login-container">
          <form id="login" action="" method="post">
            <input type="text" name="username" placeholder="Username" class="login-input">
            <input type="password" name="password" placeholder="Password" class="login-input">
            <input id="loginButton" type="submit" value="Login" class="login-button">
          </form>
        </div>
        <div class="alert"></div>
    </header>';
}
?>

<script type="text/javascript">
    $('#login').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: "./includes/login.php",
            method: "POST",
            data: new FormData(this),
            contentType: false,
            dataType: "json",
            processData: false,
            success: function(data) {
                if (data[0] == 'yes') {
                    $('.alert').html('Je bent aangemeld');
                    $('.alert').css({
                        'background-color': '#69be6c',
                        'padding': '20px'
                    });
                    $('.alert').slideDown("Slow");
                    setTimeout(function() {
                        $('.alert').slideUp("Slow");
                        $('.alert').css({
                            'padding': '0px'
                        });
                    }, 2000);
                    setTimeout(function() {
                        window.location.href = "./admin.php";
                    }, 3000);
                } else {
                    $('.alert').html(data[1]);
                    $('.alert').css({
                        'background-color': '#dd625d',
                        'padding': '20px'
                    });
                    $('.alert').slideDown("Slow");
                    setTimeout(function() {
                        $('.alert').slideUp("Slow");
                        $('.alert').css({
                            'padding': '0px'
                        });
                    }, 2000);
                }
            }
        })
    });

    function logout() {
        $.ajax({
            url: './includes/logout.php',
            method: 'POST',
            data: {},
            dataType: 'json',
            success: function(data) {
                window.location.href = './index.php';
            }
        })
    }
</script>

<!-- Add some CSS -->
<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        background-color: #333;
        color: white;
    }

    .logo-container {
        flex: 1;
    }

    .logo {
        width: 150px;
    }

    ul {
        display: flex;
        list-style-type: none;
        gap: 20px;
    }

    ul a {
        color: white;
        text-decoration: none;
    }

    .login-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        background-color: #333;
        color: white;
    }

    .login-container {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .login-input {
        padding: 8px;
        border: none;
        border-radius: 5px;
    }

    .login-button {
        padding: 10px 20px;
        background-color: #69be6c;
        border: none;
        border-radius: 5px;
        color: white;
        cursor: pointer;
    }
    .logout-button {
        padding: 10px 20px;
        background-color:rgb(255, 0, 0);
        border: none;
        border-radius: 5px;
        color: white;
        cursor: pointer;
    }

    .login-button:hover {
        background-color: #57a855;
    }

    .alert {
        display: none;
        margin-top: 10px;
        padding: 10px;
        border-radius: 5px;
    }
</style>