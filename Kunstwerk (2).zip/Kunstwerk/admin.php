<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - QR-code beheer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./js/qr-delete.js"></script>
    <script src="./js/qr-duplicate.js"></script>
</head>

<body>
    <?php
    include './includes/dbh.php';
    include './js/get-qr-code.php';
    include './header.php';

    ?>
    <div class="container mt-5">
        <h1 class="mb-4">Museum Beheer</h1>
        <a href="qr-code-insert.php" class="btn btn-primary mb-3">
            <i class="fa fa-plus"></i>Nieuwe museum stuk aanmaken
        </a>
        <div id="qr-code-content"></div>
    </div>
</body>

</html>

<script>
    function downloadImg (imageUrl) {
                fetch(imageUrl)
            .then(response => response.blob())
            .then(blob => {
                console.log(blob);
                
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = 'qrcode.png';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
            })
            .catch(() => alert('Download mislukt.'));
    }
</script>