<?php
include './dbh.php'; 
function generateUUIDv4() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}


$response = array();
$id = $_POST['id'];
$nieuweId = generateUUIDv4();

// Eerste statement: SELECT
$sql = "SELECT title, content, tijdsperk, image FROM dries_qr_codes WHERE id = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('s', $id); 
$statement->execute();
$statement->bind_result($title, $content, $tijdsperk, $image); 
$statement->fetch();
$statement->close(); // BELANGRIJK: sluit het statement na gebruik

// Tweede statement: INSERT
$sql = "INSERT INTO `dries_qr_codes` (`id`, `title`, `content`, `tijdsperk`, `image`) VALUES (?, ?, ?, ?, ?)";
$statement = $conn->prepare($sql);
$statement->bind_param('sssss', $nieuweId, $title, $content, $tijdsperk, $image);
$statement->execute();
$statement->close(); 

echo json_encode($response);
?>
