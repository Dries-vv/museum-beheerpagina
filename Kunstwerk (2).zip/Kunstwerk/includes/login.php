<?php
include './dbh.php'; 
session_start();
$message = array('');

$username = $_POST['username'];
$password = $_POST['password'];

if (empty($username) || empty($password)) {
  $message[0] = 'no';
  $message[1] = 'Niet alle velden ingevuld';
} else {
  $sql = "SELECT * FROM dries_users WHERE username='$username'";
  $result = mysqli_query($conn, $sql);
  $resultCheck = mysqli_num_rows($result);
  if ($resultCheck < 1){
    $message[0] = 'no';
    $message[1] = 'Geen gebruiker gevonden';
  } else {
    if ($row = mysqli_fetch_assoc($result)) {
      if ($password != $row['password']) {
        $message[0] = 'no';
        $message[1] = 'Wachtwoord incorrect';
      } elseif ($password == $row['password']) {
        $_SESSION['user'] = $username;
        $message[0] = 'yes';
        $message[1] = $username;
      }
    }
  }
}
echo json_encode($message);
