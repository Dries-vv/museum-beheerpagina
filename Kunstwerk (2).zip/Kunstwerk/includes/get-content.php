<?php
$response = array();
$html = '';
include './dbh.php';

$sql = "SELECT * FROM dries_qr_codes";
$result = $conn->query($sql);

// Begin HTML + CSS styling
$html .= '
<style>
body {
    margin: 0;
    padding: 0;
    font-family: "Georgia", serif;
    background-color: #f9f6f1;
    color: #2c2c2c;
}

    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #ffffff;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        border-radius: 8px;
        overflow: hidden;
    }

    thead tr {
        background-color: #ded7cb;
        color: #3d3d3d;
        font-size: 1.05em;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    th, td {
        padding: 14px 16px;
        border: 1px solid #e0e0e0;
    }

    tbody tr:nth-child(odd) {
        background-color: #fefcf9;
    }

    tbody tr:nth-child(even) {
        background-color: #f3efe7;
    }

    td img {
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 4px;
        background-color: #fff;
        transition: transform 0.2s ease-in-out;
    }

    td img:hover {
        transform: scale(1.05);
    }

    a {
        color: #5c4430;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    td div a i {
        font-size: 1.1em;
        color: #5c4430;
        padding: 6px;
        transition: color 0.2s;
    }

    td div a i:hover {
        color: #a6753d;
    }

    td > div {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    td img[alt="Afbeelding"] {
        max-width: 80px;
        height: auto;
        border-radius: 4px;
    }

    td img[alt="QR Code"] {
        box-shadow: 0 0 10px rgba(166, 117, 61, 0.3);
    }
    td .action-buttons {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        gap: 10px;
        padding: 8px 0;
    }

    td .action-buttons a i {
        font-size: 1.3em;
        color: #5c4430;
        padding: 8px;
        transition: color 0.2s, transform 0.2s;
    }

    td .action-buttons a i:hover {
        color: #a6753d;
        transform: scale(1.2);
    }
    
</style>
';

$html .= '<table>';
$html .= '<thead>';
$html .= '<tr>';
$html .= '<th>Foto</th>';
$html .= '<th>Titel</th>';
$html .= '<th>Content</th>';
$html .= '<th>Tijdsperk</th>';
$html .= '<th>QR CODE</th>';
$html .= '<th>Acties</th>';
$html .= '</tr>';
$html .= '</thead>';
$html .= '<tbody>';

while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $title = $row['title'];
    $content = $row['content'];
    $tijdsperk = $row['tijdsperk'];
    $image = $row['image'];

    $html .= '<tr>';
    $html .= '<td><img src="' . htmlspecialchars($image) . '" alt="Afbeelding"></td>';
    $html .= '<td>' . htmlspecialchars($title) . '</td>';
    $html .= '<td>' . htmlspecialchars_decode($content) . '</td>';
    $html .= '<td>' . htmlspecialchars($tijdsperk) . '</td>';
    $html .= '<td>';
    $html .= '<div>';
    $html .= '<img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=http://vanvelthovendries.provil-ict.be/kunstwerk/schilderij.php?id=' . $id . '" style="width: 100px; height: 100px;" alt="QR Code">';
    $html .= '<a target="_blank" href="http://vanvelthovendries.provil-ict.be/kunstwerk/schilderij.php?id=' . $id . '">Link</a>';
    $html .= '</div>';
    $html .= '</td>';
    $html .= '<td>';
    $html .= '<div class="action-buttons">';
    $html .= '<a onclick="downloadImg(\'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=/schilderij.php?id=' . $id . '\')"><i class="fa fa-download"></i></a>';
    $html .= '<a href="qr-code-update.php?id=' . $id . '"><i class="fa-solid fa-pen-to-square"></i></a>';
    $html .= '<a href="#" onclick="duplicateQR(\'' . $id . '\')"><i class="fa-solid fa-copy"></i></a>';
    $html .= '<a href="#" onclick="deleteQR(\'' . $id . '\')"><i class="fa fa-trash"></i></a>';
    $html .= '</div>';
    $html .= '</td>';
    
}

$html .= '</tbody>';
$html .= '</table>';

$response['html'] = $html;
echo json_encode($response);
