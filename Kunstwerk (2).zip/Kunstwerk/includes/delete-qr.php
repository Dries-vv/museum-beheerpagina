<?php

include './dbh.php'; 
$id = $_POST['id']; 
$response = array();

$sql = "DELETE FROM dries_qr_codes WHERE id = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('s', $id);
$statement->execute();

echo json_encode($response);
?>
