<?php
$hostname = '160.153.132.203';
$username = 'gip_museum';
$password = '9&b-AZ.JWMCo(oz';
$database = 'gip_museum';

$conn = mysqli_connect($hostname,$username,$password,$database );


?>      