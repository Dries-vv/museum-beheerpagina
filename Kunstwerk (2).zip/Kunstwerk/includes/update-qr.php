<?php
include "./dbh.php";
$response = array();

$nieuweTitle = $_POST['nieuweTitle'];
$nieuweContent = $_POST['nieuweContent'];
$nieuweTijdsperk = $_POST['nieuweTijdsperk'];
$nieuweImage = $_POST['nieuweImage'];
$QRid = $_POST['QRid'];





$sql = "UPDATE `dries_qr_codes` SET `title` = ?, `content` = ?, `tijdsperk` = ?, `image` = ? WHERE `id` = ?";
$statement = $conn->prepare($sql);

$statement->bind_param('sssss', $nieuweTitle, $nieuweContent, $nieuweTijdsperk, $nieuweImage,$QRid);

$statement->execute();

echo json_encode($response);


?>