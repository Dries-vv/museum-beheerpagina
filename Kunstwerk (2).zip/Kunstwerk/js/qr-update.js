function updateQR() {
    const nieuweTitle = $('#nieuweTitle').val();
    const nieuweContent = $('#nieuweContent').val();
    const nieuweTijdsperk = $('#nieuweTijdsperk').val();
    const nieuweImage = $('#nieuweImage').val();
    const QRid = $('#QRid').val();


    $.ajax({
        url:'./includes/update-qr.php',
        method:'POST',
        data:{
            nieuweTitle,
            nieuweContent,
            nieuweTijdsperk,
            nieuweImage,
            QRid
        },  
        dataType:'json',
        success: function () {
            console.log('yeah');
            $('#succesMessageUpdate').css({'display':'block'})
            $('#succesMessageUpdate').html('QR code geupdate!')
            setTimeout(function() {
                window.location.href = "./admin.php";
            }, 3000);
        }

    })
}