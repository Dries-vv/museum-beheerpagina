<?php
include './includes/dbh.php'
?>
<script>
    $(document).ready(function() {
        getQR()
    });

    function getQR() {
        $.ajax({
            url: './includes/get-content.php',
            data: {},
            method: 'POST',
            dataType: 'JSON',
            success: function(data) {
                console.log(data)
                $("#qr-code-content").html(data['html']);

            }


        });

    }
</script>