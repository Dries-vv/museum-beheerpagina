function deleteQR(id) {
    if (confirm('Weet je zeker dat je deze QR-code wilt verwijderen?')) {
        $.ajax({
            url: './includes/delete-qr.php',
            method: 'POST',
            data: {
                id: id
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    alert('QR code verwijderd!');

                }
            },
        })
    }
}
