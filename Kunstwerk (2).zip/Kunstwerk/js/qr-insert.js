
function insertQR() {
    const title = $('#title').val();
    const content = $('#content').val();
    const tijdsperk = $('#tijdsperk').val();
    const image = $('#image').val();

    if (!title || !content || !tijdsperk || !image ) {
        $('#errorMessage').css({ 'display': 'block' })
        $('#errorMessage').html('Niet alle velden zijn ingevuld')

    } else {
        $.ajax({
            url: './includes/insert-qr.php',
            method: 'POST',
            data: {
                title,
                content,
                tijdsperk,
                image
            },
            datatype: 'json',
            success: function (data) {
                console.log('yeah');
                $('#succesMessage').css({ 'display': 'block' })
                $('#succesMessage').html('QR code toegevoegd')
                setTimeout(function() {
                    window.location.href = "./admin.php";
                }, 3000);
            }

        }
        )
    }
}