
function duplicateQR(id) {
    $.ajax({
        url: './includes/duplicate-qr.php',
        method: 'POST',
        data: {
            id: id
        },
        dataType: 'json',
        success: function () {
            console.log('yeah');
            alert('QR code gedupliceerd!');
            $('#succesMessage').html('QR code toegevoegd')
        }
    })
}
