<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-code toevoegen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/ui/trumbowyg.min.css">
    <script src="./js/qr-insert.js"> </script>

</head>

<body>
    <div class="container mt-5">
        <h1 class="mb-4">Museum stuk toevoegen</h1>

        <form>
            <div class="mb-3">
                <label for="title" class="form-label">Titel</label>
                <input type="text" class="form-control" id="title" placeholder="Voer een titel in">
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Tekst</label>
                <textarea id="content" class="form-control"></textarea>
            </div>

            <div class="mb-3">
                <label for="tijdsperk" class="form-label">Tijdperk</label>
                <input type="text" class="form-control" id="tijdsperk" placeholder="Voer een tijdperk in">
            </div>

            <div class="mb-3">
                <label for="era" class="form-label">Image URL</label>
                <input type="text" class="form-control" id="image" placeholder="Geef de image url">
            </div>

            <div onclick="insertQR()" class="btn btn-primary" style="cursor:pointer;">Opslaan</div>
            <div id="errorMessage"  class="alert alert-danger mt-3 text-center" style="display: none;"></div>
            <div id="succesMessage"  class="alert alert-success mt-3 text-center" style="display: none;"></div>

        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/trumbowyg.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#content').trumbowyg();
        });
    </script>
</body>

</html>