<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

include('./includes/dbh.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM dries_qr_codes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    $row = $result->fetch_assoc();
    $title = $row['title'];
    $content = $row['content'];
    $tijdsperk = $row['tijdsperk'];
    $image = $row['image'];
} else {
    echo "Geen id gevonden!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bewerk QR</title>

    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/ui/trumbowyg.min.css">
    <link rel="stylesheet" href="./style/style-edit.css">


    <!-- Museum Styling -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Georgia', serif;
            background-color: #f9f6f1;
            color: #2c2c2c;
            padding: 40px;
        }

        h2 {
            font-size: 2rem;
            font-weight: bold;
            color: #5c4430;
            margin-bottom: 30px;
        }

        label {
            font-weight: 600;
            color: #3b2c1a;
        }

        .form-control {
            background-color: #fcf8f3;
            border: 1px solid #d4c5b2;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #a6753d;
            box-shadow: 0 0 5px rgba(166, 117, 61, 0.4);
        }

        .btn-primary {
            background-color: #a6753d;
            border-color: #a6753d;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #915f2e;
            border-color: #915f2e;
        }

        .alert {
            max-width: 600px;
            margin: 0 auto;
        }

        .container-museum {
            max-width: 700px;
            margin: auto;
            background-color: #fffdf9;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }
    </style>

    <script src="./js/qr-update.js"></script>
</head>

<body>

    <div class="container-museum">
        <h2>Bewerk QR-code</h2>

        <input type="hidden" id="QRid" name="id" value="<?php echo $id; ?>">

        <div class="mb-3">
            <label for="title" class="form-label">Titel</label>
            <input type="text" class="form-control" id="nieuweTitle" name="title" value="<?php echo $title; ?>" placeholder="Voer een titel in">
        </div>

        <div class="mb-3">
            <label for="content" class="form-label">Tekst</label>
            <textarea id="nieuweContent" name="content" class="form-control" placeholder="Voer de tekst in"><?php echo $content; ?></textarea>
        </div>

        <div class="mb-3">
            <label for="tijdsperk" class="form-label">Tijdperk</label>
            <input type="text" class="form-control" id="nieuweTijdsperk" name="tijdsperk" value="<?php echo $tijdsperk; ?>" placeholder="Voer een tijdperk in">
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Afbeelding URL</label>
            <input type="text" class="form-control" id="nieuweImage" name="image" value="<?php echo $image; ?>" placeholder="Geef de image URL">
        </div>

        <div onclick="updateQR()" class="btn btn-primary">Opslaan</div>

        <div id="errorMessageUpdate" class="alert alert-danger mt-3 text-center" style="display: none;"></div>
        <div id="succesMessageUpdate" class="alert alert-success mt-3 text-center" style="display: none;"></div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/trumbowyg.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#nieuweContent').trumbowyg();
        });
    </script>
</body>

</html>
