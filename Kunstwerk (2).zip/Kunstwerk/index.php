<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login Pagina</title>
  <link rel="stylesheet" href="./style/style-login.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="./js/login.js" defer></script>
</head>
<body>
  <div class="container">
    <div class="left">
      <h1>Welkom bij het Grevenbroekmuseum</h1>
      <p>
        Welkom! Via deze adminpagina kun je het online museum beheren.
      </p>
    </div>
    <div class="right">
      <div class="login-box">
        <h2>Admin LOGIN</h2>

        <!-- Geen form -->
        <input type="text" id="username" placeholder="Username" />
        <input type="password" id="password" placeholder="Password" />
        <div class="options">
          <label><input type="checkbox">Remember me</label>
          <a href="#">Maak account</a>
        </div>
        <button onclick="login()" class="btn btn-primary">Inloggen</button>
        <div class="alert"></div>
      </div>
    </div>
  </div>
</body>
</html>
